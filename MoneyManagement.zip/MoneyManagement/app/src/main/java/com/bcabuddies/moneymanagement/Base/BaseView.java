package com.bcabuddies.moneymanagement.Base;

import android.content.Context;

//this interface will get the context of the parent activity
public interface BaseView {
    Context getContext();
}
